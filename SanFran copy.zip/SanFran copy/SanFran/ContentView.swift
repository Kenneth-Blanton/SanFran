//
//  ContentView.swift
//  SanFran
//
//  Created by Kenneth Blanton on 12/12/21.
//

import SwiftUI

struct ContentView: View {
    let pictures = ["San Fran Me 1", "San Fran Me 2", "San Fran Me 3"]
    let captions = ["This is me in Lafayette Park", "This is The Mission District", "This is the court house in San Francisco"]
    @State var picture = ""
    @State var caption = ""
    @State var picNum = 0
    @State var capNum = 0
    let picMax = 2
    let picMin = 0
    let capMax = 2
    let capMin = 0
    
    var body: some View {
        ZStack{
            Image("Yellow")
            VStack{
                Text("My Trip to San Francisco 2021")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .padding(.horizontal, 15)
                    .background(Color.orange)
                    .shadow(color: Color.white, radius: 100)
            Image(pictures[picNum])
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: 520)
                Text(captions[capNum])
                    .font(.footnote)
                    .foregroundColor(Color.white)
                    .padding(.horizontal, 115)
                    .padding(.vertical, 5)
                    .background(Color.black)
                    .shadow(color: Color.white, radius: 400)
                    .padding(.bottom, 5)
                    .padding(.top, -15)
                HStack{
                    Button(action: {
                        picture = pictures[picNum]
                        picNum -= 1
                        if (picNum < picMin){
                            picNum = picMax
                        }
                        caption = captions[capNum]
                        capNum -= 1
                        if (capNum < capMin){
                            capNum = capMax
                        }
                    
                }, label: {
                    Image(systemName: "arrow.backward")
                        .foregroundColor(Color.black)
                    Text("Previous")
                        .font(.body)
                        .foregroundColor(Color.black)
                        .padding(.horizontal, 20)
                        .background(Color.orange
                                        .cornerRadius(10)
                                        .shadow(radius: 3)
                        )
                        
                })
                        .padding(.trailing, 120)
                        .padding(.leading, -90)
                    Button(action: {
                        picture = pictures[picNum]
                        picNum += 1
                        if (picNum > picMax){
                            picNum = picMin
                        }
                        caption = captions[capNum]
                        capNum += 1
                        if (capNum > capMax){
                            capNum = capMin
                        }
                        
                    }, label: {
                        Text("Next")
                            .font(.body)
                            .foregroundColor(Color.black)
                            .padding(.horizontal, 20)
                            .background(Color.orange
                                            .cornerRadius(10)
                                            .shadow(radius: 3)
                            )
                        Image(systemName: "arrow.forward")
                            .foregroundColor(Color.black)
                    })
                        .padding(.trailing, -75)
                }
                
            }
            }
        }
    }


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
