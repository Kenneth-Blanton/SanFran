//
//  SanFranApp.swift
//  SanFran
//
//  Created by Kenneth Blanton on 12/12/21.
//

import SwiftUI

@main
struct SanFranApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
